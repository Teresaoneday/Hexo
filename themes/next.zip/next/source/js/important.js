$(document).ready(function() {
	function setComments(){
        $(".ds-time").show();
    }
    setTimeout(setComments,2000)
});